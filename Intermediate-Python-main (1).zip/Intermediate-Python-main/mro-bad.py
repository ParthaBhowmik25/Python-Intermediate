class A(object): pass

class B(object): pass

class X(A, B): pass

class Y(B, A): pass

class Z(X, Y): pass
