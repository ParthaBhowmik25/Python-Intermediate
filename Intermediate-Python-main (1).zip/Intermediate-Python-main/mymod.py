def weird_func():
    return [None] * 3
    
print(f'__name__ is {__name__}')