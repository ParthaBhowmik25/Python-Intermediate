"""A bunch of shared functions for the doohickey team."""

FOO_BAR = "foo...bar"


def func1():
    """func1"""
    print("this is func1")


def func2(x):
    """func2"""
    return x + 1


def func3(x, y, z):
    """func3"""
    return x + y + z
