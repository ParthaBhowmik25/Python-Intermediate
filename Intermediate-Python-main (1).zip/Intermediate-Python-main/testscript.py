from script import main
import unittest

Class TestScript(unittest.testcase):
     def setUp(self):
         pass

    def test_main(self):
       pass
 
