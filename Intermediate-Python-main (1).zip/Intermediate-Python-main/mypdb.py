class PdbTester():
    def __init__(self, count):
        self.count = count

    def doit(self):
        for i in range(self.count):
            print(i)
